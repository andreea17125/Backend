﻿namespace TerrainApp.API.DataAbstraction
{
    public class Class1
    {

    }
}
