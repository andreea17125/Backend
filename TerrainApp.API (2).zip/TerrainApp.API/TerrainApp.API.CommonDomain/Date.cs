﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TerrainApp.API.CommonDomain
{
    public class Date
    {
        public int Day;
        public EMonth Month = EMonth.November;
        public int Year;

    }
}
