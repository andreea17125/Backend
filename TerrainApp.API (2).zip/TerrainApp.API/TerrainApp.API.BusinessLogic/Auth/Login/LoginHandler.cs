﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using Microsoft.IdentityModel.Tokens;

namespace TerrainApp.API.BusinessLogic.Auth.Login
{
    public class LoginHandler : IRequestHandler<LoginRequest, LoginResponse>
    {
        public async Task<LoginResponse> Handle(LoginRequest request, CancellationToken cancellationToken)
        {
            //cauta mi user ul in db dupa email si parola verificam daca datele sunt valide
            var refreshToken = GenerateRefreshToken();
            var Response = GenerateAccessToken(request.Email);
            LoginResponse response = new LoginResponse();
            response.AccessToken = new JwtSecurityTokenHandler().WriteToken(Response);
            response.RefreshToken = refreshToken;
            response.ExpiresIn = 60;
            return response;
        }
    
    private JwtSecurityToken GenerateAccessToken(string Email)
        {
            var claims = new List<Claim>
                                         { 
                           new Claim(ClaimTypes.Name, Email)
                                         };

            var token = new JwtSecurityToken(
                issuer: "localhost",
                audience: "localhost",
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(1), // Token expiration time
                signingCredentials: new SigningCredentials(
                    new SymmetricSecurityKey(Encoding.UTF8.GetBytes("averylongsecretkeythatisrequiredtobeused")),
                    SecurityAlgorithms.HmacSha256)
            );

            return token;
        }
        private string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber); // Secure random refresh token
            }
        }
    }
}
