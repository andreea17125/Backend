﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using Microsoft.IdentityModel.Tokens;

namespace TerrainApp.API.BusinessLogic.Auth.Refresh
{
    public class RefreshHandler : IRequestHandler<RefreshRequest, RefreshResponse>
    {
        private static Dictionary<string, string> RefreshTokens = new Dictionary<string, string>();

        public async Task<RefreshResponse> Handle(RefreshRequest request, CancellationToken cancellationToken)
        {
            //cauta mi user ul in db dupa email verificam daca datele sunt valide

            var email = request.Email;
            var newAccessToken = GenerateAccessToken(email);
            var newRefreshToken = GenerateRefreshToken();


            RefreshResponse refreshResponse = new RefreshResponse();
            refreshResponse.RefreshToken = newRefreshToken;
            refreshResponse.AccessToken = new JwtSecurityTokenHandler().WriteToken(newAccessToken);
            refreshResponse.ExpiresIn = 60;
            return refreshResponse;


        }
        private string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber); // Secure random refresh token
            }
        }
        private JwtSecurityToken GenerateAccessToken(string RefreshToken)
        {
            var claims = new List<Claim>
                                         {
                           new Claim(ClaimTypes.Name, RefreshToken)
                                         };

            var token = new JwtSecurityToken(
                issuer: "localhost",
                audience: "localhost",
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(1), // Token expiration time
                signingCredentials: new SigningCredentials(
                    new SymmetricSecurityKey(Encoding.UTF8.GetBytes("averylongsecretkeythatisrequiredtobeused")),
                    SecurityAlgorithms.HmacSha256)
            );

            return token;
        }
    }
}

