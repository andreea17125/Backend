﻿namespace TerrainApp.API.BusinessLogic
{
    public class Class1
    {

    }
}
