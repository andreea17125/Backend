﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using MongoDB.Driver;
using TerrainApp.API.DataAbstraction.IDataBase;
using TerrainApp.API.Domain.UserDomain;
using TerrainApp.API.Repositories;

namespace TerrainApp.API.BusinessLogic.Users.GetUser
{
    public class GetUserHandler : IRequestHandler<GetUserRequest, GetUserResponse>
    {
       
        private UserRepository userRepository = null;
        public GetUserHandler(UserRepository originaluserRepository)
        {
           this.userRepository = originaluserRepository;
        }

        public async Task<GetUserResponse> Handle(GetUserRequest request, CancellationToken cancellationToken)
        {
         var user =  await userRepository.GetById(request.UserId);
            

            return new GetUserResponse
            {
                User = user,
                Message = user != null ? "User retrieved successfully" : "User not found",
                StatusCode = user != null ? System.Net.HttpStatusCode.OK : System.Net.HttpStatusCode.NotFound
            };
        }
    }
}
