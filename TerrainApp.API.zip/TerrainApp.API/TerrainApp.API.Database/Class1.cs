﻿namespace TerrainApp.API.Database
{
    public class Class1
    {

    }
}
