﻿namespace TerrainApp.API.Repositories
{
    public class Class1
    {

    }
}
