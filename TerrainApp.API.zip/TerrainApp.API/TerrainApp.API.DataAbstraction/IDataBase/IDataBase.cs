﻿using MongoDB.Driver;

namespace TerrainApp.API.DataAbstraction.IDataBase
{
    public interface IDataBase
    {
        IMongoDatabase GetMongoDatabase();

    }
}
