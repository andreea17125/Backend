﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TerrainApp.API.CommonDomain
{
    public enum EnumCity
    {
        NewYork,
        London,
        Paris,
        Sydney,
        Cairo,
        Tokyo,
        Beijing,
        RioDeJaneiro,
        Moscow,
        Mumbai,
        Berlin,
        BuenosAires,
        Istanbul,
        Bangkok,
        Dubai,
        Nairobi,
        Rome,
        Toronto,
        MexicoCity,
        Jakarta,
        Madrid,
        Athens

    }
}
