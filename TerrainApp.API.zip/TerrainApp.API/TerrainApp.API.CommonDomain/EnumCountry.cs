﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TerrainApp.API.CommonDomain
{
    public enum EnumCountry
    {
        UnitedStates,
        Canada,
        Brazil,
        Argentina,
        Mexico,
        France,
        Germany,
        Italy,
        UnitedKingdom,
        Spain,
        Russia,
        China,
        Japan,
        SouthKorea,
        India,
        Australia,
        NewZealand,
        SouthAfrica,
        Egypt

    }
}
